"""Логика команд Джарвиса: превращает распознанную фразу в действие."""
import ctypes
import datetime
import difflib
import json
import os
import re
import subprocess
import sys
import urllib.parse
import webbrowser
from pathlib import Path

if getattr(sys, "frozen", False):  # запущено из собранного Jarvis.exe
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent
APPS_FILE = BASE_DIR / "apps.json"

# True  -> Джарвис реагирует только на фразы вида "Джарвис, открой блокнот"
# False -> реагирует на любые команды ("открой блокнот")
REQUIRE_WAKE_WORD = False
WAKE_WORDS = ("джарвис", "жарвис", "джарвиз", "джарвес")

OPEN_VERBS = ("открой", "запусти", "включи")
CLOSE_VERBS = ("закрой", "закрыть", "заверши")
SEARCH_VERBS = ("найди", "поищи", "загугли", "погугли", "найти")
KIND_WORDS = ("сайт", "программу", "программа", "приложение", "игру")

MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
          "августа", "сентября", "октября", "ноября", "декабря"]
WEEKDAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]

VK_VOLUME_MUTE, VK_VOLUME_DOWN, VK_VOLUME_UP = 0xAD, 0xAE, 0xAF
VK_LWIN, VK_D = 0x5B, 0x44
KEYEVENTF_KEYUP = 0x0002
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

HELP_TEXT = (
    "Я умею: «открой <программа или сайт>», «закрой <программа>», "
    "«найди <запрос>», «который час», «какое сегодня число», "
    "«громче», «тише», «выключи звук», «сверни все окна», «заблокируй компьютер». "
    "Новые программы добавляются в файл apps.json."
)


def normalize(text: str) -> str:
    text = text.lower().replace("ё", "е")
    text = re.sub(r"[^\w\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def press_keys(*vks: int) -> None:
    """Нажимает клавиши (в Windows) — так управляем громкостью и окнами."""
    if sys.platform != "win32":
        return
    user32 = ctypes.windll.user32
    for vk in vks:
        user32.keybd_event(vk, 0, 0, 0)
    for vk in reversed(vks):
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def run_target(target: str) -> None:
    """Открывает программу, файл, ссылку или системный адрес (например ms-settings:)."""
    target = os.path.expandvars(target)
    if target.startswith(("http://", "https://")):
        webbrowser.open(target)
        return
    if sys.platform != "win32":
        raise OSError("запуск программ работает только в Windows")
    cmd = f'start "" "{target}"' if os.path.exists(target) else f'start "" {target}'
    subprocess.Popen(cmd, shell=True, creationflags=NO_WINDOW)


def kill_process(process: str) -> bool:
    result = subprocess.run(["taskkill", "/IM", process, "/F"],
                            capture_output=True, creationflags=NO_WINDOW)
    return result.returncode == 0


def _is(text: str, *phrases: str) -> bool:
    return any(text == p or text.startswith(p + " ") for p in phrases)


class CommandProcessor:
    def __init__(self) -> None:
        self.apps: dict = {}
        self.sites: dict = {}
        self.reload()

    def reload(self) -> None:
        data = json.loads(APPS_FILE.read_text(encoding="utf-8"))
        self.apps, self.sites = {}, {}
        for name, info in data.get("apps", {}).items():
            entry = {"name": name, "target": info["run"], "process": info.get("process")}
            for key in [name, *info.get("aliases", [])]:
                self.apps[normalize(key)] = entry
        for name, info in data.get("sites", {}).items():
            entry = {"name": name, "target": info["url"], "process": None}
            for key in [name, *info.get("aliases", [])]:
                self.sites[normalize(key)] = entry

    # ---------- главный вход ----------
    def handle(self, raw: str):
        """Возвращает ответ Джарвиса (строку) или None, если фразу надо проигнорировать."""
        words = normalize(raw).split()
        if not words:
            return None
        if words[0] in WAKE_WORDS:
            words = words[1:]
            if not words:
                return "Слушаю."
        elif REQUIRE_WAKE_WORD:
            return None
        try:
            for handler in (self._system, self._search, self._open, self._close):
                reply = handler(words)
                if reply:
                    return reply
        except Exception as exc:  # noqa: BLE001
            return f"Не получилось выполнить команду: {exc}"
        return f"Не понял команду: «{' '.join(words)}»"

    # ---------- системные команды ----------
    def _system(self, words):
        text = " ".join(words)
        now = datetime.datetime.now()
        if _is(text, "который час", "сколько времени", "сколько сейчас времени", "скажи время", "время"):
            return f"Сейчас {now:%H:%M}."
        if _is(text, "какое сегодня число", "какое число", "какая сегодня дата", "какая дата",
               "какой сегодня день", "дата"):
            return f"Сегодня {WEEKDAYS[now.weekday()]}, {now.day} {MONTHS[now.month - 1]} {now.year} года."
        if _is(text, "громче", "прибавь звук", "увеличь громкость"):
            for _ in range(5):
                press_keys(VK_VOLUME_UP)
            return "Делаю громче."
        if _is(text, "тише", "убавь звук", "уменьши громкость"):
            for _ in range(5):
                press_keys(VK_VOLUME_DOWN)
            return "Делаю тише."
        if _is(text, "без звука", "выключи звук", "отключи звук", "включи звук", "верни звук"):
            press_keys(VK_VOLUME_MUTE)
            return "Переключаю звук."
        if _is(text, "заблокируй компьютер", "заблокируй экран", "заблокируй"):
            if sys.platform == "win32":
                ctypes.windll.user32.LockWorkStation()
            return "Блокирую компьютер."
        if _is(text, "сверни все окна", "сверни окна", "покажи рабочий стол"):
            press_keys(VK_LWIN, VK_D)
            return "Сворачиваю окна."
        if _is(text, "помощь", "что ты умеешь", "что ты можешь"):
            return HELP_TEXT
        return None

    # ---------- поиск в интернете ----------
    def _search(self, words):
        if words[0] not in SEARCH_VERBS or len(words) < 2:
            return None
        query = re.sub(r"\bв интернете\b", "", " ".join(words[1:])).strip()
        if not query:
            return None
        webbrowser.open("https://yandex.ru/search/?text=" + urllib.parse.quote(query))
        return f"Ищу: {query}"

    # ---------- открыть ----------
    def _open(self, words):
        if words[0] not in OPEN_VERBS or len(words) < 2:
            return None
        rest = [w for w in words[1:] if w != "пожалуйста"]
        prefer_site = bool(rest) and rest[0] == "сайт"
        if rest and rest[0] in KIND_WORDS:
            rest = rest[1:]
        name = " ".join(rest)
        if not name:
            return None
        entry = self._find(name, prefer_site)
        if entry is None:
            return f"Не знаю, что такое «{name}». Добавь это в apps.json."
        run_target(entry["target"])
        return f"Открываю {entry['name']}."

    # ---------- закрыть ----------
    def _close(self, words):
        if words[0] not in CLOSE_VERBS or len(words) < 2:
            return None
        rest = [w for w in words[1:] if w != "пожалуйста"]
        if rest and rest[0] in KIND_WORDS:
            rest = rest[1:]
        name = " ".join(rest)
        entry = self._find(name, False) if name else None
        if entry is None:
            return f"Не знаю, что такое «{name}»."
        if not entry["process"]:
            return f"Для «{entry['name']}» не указан процесс, закрыть не могу."
        if kill_process(entry["process"]):
            return f"Закрыл {entry['name']}."
        return f"{entry['name']} сейчас не запущено."

    # ---------- поиск по названию (с учётом ошибок распознавания) ----------
    def _find(self, name: str, prefer_site: bool):
        order = [self.sites, self.apps] if prefer_site else [self.apps, self.sites]
        for index in order:
            if name in index:
                return index[name]
        for index in order:
            close = difflib.get_close_matches(name, list(index), n=1, cutoff=0.72)
            if close:
                return index[close[0]]
        return None
