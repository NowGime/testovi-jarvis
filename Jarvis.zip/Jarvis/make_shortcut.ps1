$desktop = [Environment]::GetFolderPath('Desktop')
$shell = New-Object -ComObject WScript.Shell
$s = $shell.CreateShortcut((Join-Path $desktop 'Jarvis.lnk'))
$s.TargetPath = Join-Path $PSScriptRoot 'python\pythonw.exe'
$s.Arguments = 'jarvis.py'
$s.WorkingDirectory = $PSScriptRoot
$icon = Join-Path $PSScriptRoot 'jarvis.ico'
if (Test-Path $icon) { $s.IconLocation = $icon }
$s.Description = 'Jarvis'
$s.Save()
