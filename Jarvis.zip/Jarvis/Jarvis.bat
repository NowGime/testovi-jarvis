@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist "python\pythonw.exe" if exist "python\installed.flag" goto run

echo ==============================================
echo   Первый запуск: готовлю Джарвиса.
echo   Нужен интернет, это займет несколько минут.
echo   Ничего не устанавливается в систему, все
echo   лежит в этой папке. Окно закроется само.
echo ==============================================
echo.

set "PYURL=https://github.com/astral-sh/python-build-standalone/releases/download/20261009/cpython-3.12.15%%2B20261009-x86_64-pc-windows-msvc-install_only.tar.gz"
set "PYSHA=194c8f0d9e0de6f1c4576e5dfa67819a48c764be87608b74b8ad43387a57b93b"

if exist "python\python.exe" goto havepython

echo [1/3] Скачиваю портативный Python, около 45 МБ...
curl.exe -L --fail -o "python_portable.tar.gz" "%PYURL%"
if errorlevel 1 goto fail

set "GOT="
for /f "skip=1 tokens=* delims=" %%H in ('certutil -hashfile "python_portable.tar.gz" SHA256') do if not defined GOT set "GOT=%%H"
set "GOT=%GOT: =%"
if /i not "%GOT%"=="%PYSHA%" goto badhash

echo [2/3] Распаковываю...
tar -xf "python_portable.tar.gz"
if errorlevel 1 goto fail
del "python_portable.tar.gz"

:havepython
echo [3/3] Устанавливаю библиотеки для распознавания речи...
"python\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto fail

echo ok> "python\installed.flag"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0make_shortcut.ps1"

:run
start "" "python\pythonw.exe" "%~dp0jarvis.py"
exit /b 0

:badhash
echo.
echo Скачанный файл не прошел проверку целостности. Удаляю его.
del "python_portable.tar.gz"
echo Запусти Jarvis.bat еще раз. Если повторится, напиши мне.
pause
exit /b 1

:fail
echo.
echo Не получилось подготовить Джарвиса. Проверь интернет и запусти Jarvis.bat еще раз.
echo Если ошибка повторяется, обнови Windows 10, в старых версиях нет программ curl и tar.
pause
exit /b 1
