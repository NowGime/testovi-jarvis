"""Джарвис — голосовой помощник для Windows. Работает офлайн, на русском."""
import json
import queue
import sys
import threading
import traceback
import urllib.request
import zipfile
from pathlib import Path

import customtkinter as ctk
import sounddevice as sd
from vosk import KaldiRecognizer, Model, SetLogLevel

from commands import CommandProcessor

if getattr(sys, "frozen", False):  # запущено из собранного Jarvis.exe
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent
MODEL_NAME = "vosk-model-small-ru-0.22"
MODEL_URL = f"https://alphacephei.com/vosk/models/{MODEL_NAME}.zip"
MODEL_DIR = BASE_DIR / "models" / MODEL_NAME
SAMPLE_RATE = 16000

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")
SetLogLevel(-1)


class JarvisApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Джарвис")
        self.geometry("580x540")
        self.minsize(460, 420)

        self.processor = CommandProcessor()
        self.ui_queue: queue.Queue = queue.Queue()
        self.audio_queue: queue.Queue = queue.Queue()
        self.model = None
        self.listening = False
        self.stop_event = threading.Event()

        self.status = ctk.CTkLabel(self, text="Запуск...", font=("Segoe UI", 16, "bold"))
        self.status.pack(pady=(14, 6))

        self.log_box = ctk.CTkTextbox(self, wrap="word", font=("Consolas", 14), state="disabled")
        self.log_box.pack(fill="both", expand=True, padx=14, pady=6)

        self.partial = ctk.CTkLabel(self, text="", text_color="gray", anchor="w")
        self.partial.pack(fill="x", padx=18)

        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.pack(fill="x", padx=14, pady=(6, 14))
        self.entry = ctk.CTkEntry(bottom, placeholder_text="Или напиши команду и нажми Enter")
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda _e: self._submit_text())
        self.toggle_btn = ctk.CTkButton(bottom, text="Слушать", width=120,
                                        command=self.toggle_listening, state="disabled")
        self.toggle_btn.pack(side="left", padx=(8, 0))

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._poll_ui)
        threading.Thread(target=self._load_model, daemon=True).start()

    # ---------- связь потоков с окном ----------
    def ui(self, kind: str, value=None) -> None:
        self.ui_queue.put((kind, value))

    def _poll_ui(self) -> None:
        try:
            while True:
                kind, value = self.ui_queue.get_nowait()
                if kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", value + "\n")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
                elif kind == "status":
                    self.status.configure(text=value)
                elif kind == "partial":
                    self.partial.configure(text=value)
                elif kind == "ready":
                    self.toggle_btn.configure(state="normal")
                    self.start_listening()
                elif kind == "listening":
                    self.toggle_btn.configure(text="Остановить" if value else "Слушать")
                    self.status.configure(text="Слушаю..." if value else "Не слушаю")
        except queue.Empty:
            pass
        self.after(100, self._poll_ui)

    # ---------- модель распознавания ----------
    def _load_model(self) -> None:
        try:
            if not (MODEL_DIR / "am").exists():
                models = MODEL_DIR.parent
                models.mkdir(exist_ok=True)
                zip_path = models / f"{MODEL_NAME}.zip"
                self.ui("log", "Скачиваю русскую модель распознавания (~45 МБ). Это только при первом запуске.")
                last = [-1]

                def hook(blocks, block_size, total):
                    if total > 0:
                        pct = min(100, blocks * block_size * 100 // total)
                        if pct // 10 != last[0]:
                            last[0] = pct // 10
                            self.ui("status", f"Загрузка модели: {pct}%")

                urllib.request.urlretrieve(MODEL_URL, zip_path, hook)
                with zipfile.ZipFile(zip_path) as archive:
                    archive.extractall(models)
                zip_path.unlink()
            self.ui("status", "Загружаю модель...")
            self.model = Model(str(MODEL_DIR))
            self.ui("log", "Джарвис готов. Скажи «что ты умеешь», чтобы узнать команды.")
            self.ui("ready")
        except Exception as exc:  # noqa: BLE001
            self.ui("status", "Ошибка запуска")
            self.ui("log", f"Не удалось загрузить модель: {exc}\nПроверь интернет и перезапусти программу.")

    # ---------- прослушивание ----------
    def toggle_listening(self) -> None:
        if self.listening:
            self.stop_event.set()
        else:
            self.start_listening()

    def start_listening(self) -> None:
        if self.listening or self.model is None:
            return
        self.listening = True
        self.stop_event = threading.Event()
        with self.audio_queue.mutex:
            self.audio_queue.queue.clear()
        self.ui("listening", True)
        threading.Thread(target=self._listen_loop, args=(self.stop_event,), daemon=True).start()

    def _listen_loop(self, stop: threading.Event) -> None:
        recognizer = KaldiRecognizer(self.model, SAMPLE_RATE)

        def callback(indata, frames, time_info, status):
            self.audio_queue.put(bytes(indata))

        try:
            with sd.RawInputStream(samplerate=SAMPLE_RATE, blocksize=4000, dtype="int16",
                                   channels=1, callback=callback):
                while not stop.is_set():
                    try:
                        data = self.audio_queue.get(timeout=0.3)
                    except queue.Empty:
                        continue
                    if recognizer.AcceptWaveform(data):
                        text = json.loads(recognizer.Result()).get("text", "")
                        self.ui("partial", "")
                        if text:
                            self._process(text)
                    else:
                        self.ui("partial", json.loads(recognizer.PartialResult()).get("partial", ""))
        except Exception as exc:  # noqa: BLE001
            self.ui("log", f"Ошибка микрофона: {exc}")
        finally:
            self.listening = False
            self.ui("partial", "")
            self.ui("listening", False)

    # ---------- обработка команд ----------
    def _process(self, text: str) -> None:
        self.ui("log", f"Вы: {text}")
        reply = self.processor.handle(text)
        if reply:
            self.ui("log", f"Джарвис: {reply}")
            self.say(reply)

    def say(self, text: str) -> None:
        """Сюда позже добавим озвучку ответов."""

    def _submit_text(self) -> None:
        text = self.entry.get().strip()
        self.entry.delete(0, "end")
        if text:
            threading.Thread(target=self._process, args=(text,), daemon=True).start()

    def _on_close(self) -> None:
        self.stop_event.set()
        self.destroy()


if __name__ == "__main__":
    try:
        JarvisApp().mainloop()
    except Exception:
        # без консоли ошибки не видны, поэтому пишем их в файл рядом с программой
        (BASE_DIR / "jarvis_error.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise
