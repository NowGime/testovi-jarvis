@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "python\installed.flag" (
    echo Сначала один раз запусти Jarvis.bat, чтобы все подготовилось.
    pause
    exit /b 1
)

echo Собираю Jarvis.exe, это займет несколько минут...
"python\python.exe" -m pip install --disable-pip-version-check pyinstaller
if errorlevel 1 goto fail

set "ICON="
if exist "jarvis.ico" set "ICON=--icon jarvis.ico"

"python\python.exe" -m PyInstaller --noconfirm --noconsole --name Jarvis %ICON% --collect-all vosk --collect-all customtkinter jarvis.py
if errorlevel 1 goto fail

copy /y apps.json "dist\Jarvis\apps.json" >nul
echo.
echo Готово. Программа лежит в папке dist\Jarvis, запускай Jarvis.exe.
echo Всю папку Jarvis можно переносить куда угодно. Список программ там в apps.json.
pause
exit /b 0

:fail
echo Не получилось собрать exe.
pause
exit /b 1
